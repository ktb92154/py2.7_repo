#from .CMDS.version import __version__ as __cmdsVersion__
#from .py_script.version import __version__ as __scriptVersion___
