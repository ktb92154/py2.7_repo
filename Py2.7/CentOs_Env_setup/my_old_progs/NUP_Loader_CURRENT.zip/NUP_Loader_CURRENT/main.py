#!/usr/local/bin/python
try:
        #----Standard Libs-------#
	import sys
	import atexit
	import ConfigParser
        #----End Standard Libs-----#
        #------Custom Scripts------#
	#from py_script.cfgLoader import *
	import py_script as AMMS_Loader
        #----End Custom Scripts----#
except ImportError as IErr:
        print('ERROR: Unable to import python lib: ' + str(IErr))
        sys.exit(1)

AMMS_Loader = AMMS_Loader.AMMS()
if __name__ == '__main__':
	while True:
        	AMMS_Loader.menu()
