#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         addHeaderFooter.py
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/                      
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems                   
#/ CONTRACT:        Northrop Grumman Aerospace Systems            
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release                                       K. Burgess
#/==============================================================================
############################################################################### 
import os, sys
cmdargs = sys.argv

def set_header(file):
	header = """\
#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         %s
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/                      
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems                   
#/ CONTRACT:        Northrop Grumman Aerospace Systems            
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release                                       K. Burgess
#/==============================================================================
############################################################################### 
""" % (str(file))
	print file
	return header

footer = """\
#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
"""

#Just add header
def write_header(dir, file):	
	header = set_header(file)
	tmp = '.tmp'
	tmpfile = str(file) + str(tmp)
	with open(os.path.join(dir, tmpfile), 'w') as tmpfile:
		tmpfile.write(header)
		
		with open(os.path.join(dir, file), 'r') as datafile:
			for line in datafile:
				tmpfile.write(line)
		tmpfile.close()


def write_footer(dir, file, footer):
	tmp = '.tmp'
	tmpfile = str(file) + str(tmp)
	with open(os.path.join(dir, tmpfile), 'a') as footerfile:
		footerfile.write(footer)
		footerfile.close()

def cleanup(dir, file, format):
	tmpfile = str(file) + str(format)
	os.remove(os.path.join(dir, file))
	os.rename(os.path.join(dir, tmpfile), os.path.join(dir, file))

if __name__ == "__main__":
	dir_path = cmdargs[1]
	filetype = '.tmp'
	if os.path.isdir(dir_path):
		for filename in os.listdir(dir_path):	
			write_header(dir_path, filename)
			write_footer(dir_path, filename, footer)
			cleanup(dir_path, filename, filetype)
	else:
		print "directory does not exist"
#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
