#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         cfgLoader.py
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/                      
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems                   
#/ CONTRACT:        Northrop Grumman Aerospace Systems            
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release  v1.0                                 K. Burgess
#/ 03/26/15    Added Capability v1.0                                 K. Burgess
#/==============================================================================
############################################################################### 
#----Standard Libs-------#
import time, datetime
import subprocess
import ConfigParser
#----End Standard Libs-----#
#------Custom Scripts------#
#from .serialMgr import mySerial
from .cmdFileMgr import cmds
from .dirMgr import mgr
from .logMgr import logger
import constants
#----End Custom Scripts----#

# Setup logger to generate logs
log = logger('cfgLoader')

class AMMS(object):
	# Constructor
	def __init__(self):
                # Initialize cfg file parser
	        self.cfgParser = ConfigParser.ConfigParser()
                
                # Get version from __init__.py
		self.program_name = constants.__program__ + ' '
		self.version = 'v' + constants. __version__
		self.script = self.program_name + self.version + ' '
                
                # Initialize directory controller
		self.dirMgr = mgr()
		self.cmdsVersion = 'Load: '+ self.dirMgr.get_cmds_type() + ' v' + self.dirMgr.get_cmds_version()
                
		# Setup configuration file parser
		self.cfgFile = self.dirMgr.set_cfg()
        	self.cfgParser.read(self.cfgFile)

		# Initialize cmdFileMgr
		self.cmds = cmds()

		self.BOARDS = ['amms_04', 'amms_05', 'amms_07', 'amms_08',
				'amms_12', 'amms_15', 'amms_16', 'amms_19']

		self.board_cmds = ['04', '05', '07', '08',
					 '12', '15', '16', '19'] #Commands for manual option
		self.switch_cmds = ['x', 'y']
		self.switch = ['gbe-x', 'gbe-y']

		# Get defaults from configuration file
		self.tfile = self.cfgParser.get('file','bin')
		self.cmdFileType = self.cfgParser.get('file', 'cmds')
		self.cmd_dir = self.cfgParser.get('folder','cmds')

		# Add current directory path to command files
		self.switchLogCmds = self.dirMgr.CMDS_path() + self.cfgParser.get('file','log_switch')
		#print 'switchLogCmds: ' + repr(self.switchLogCmds)
		self.ammsLogCmds = self.dirMgr.CMDS_path() + self.cfgParser.get('file','log_sbc')
		#print 'ammsLogCmds: ' + repr(self.ammsLogCmds)
        '''
        def menu_get_sn(self):
                cancel_options = ['quit', 'q']
                
                user_input = raw_input('Enter SN or '+ 
                                            '[' + str(cancel_options).strip('[]') +
                                            '] : ').lower()
		
		# Verify device type with user
		if not user_input or user_input not in cancel_options:
                    log.info('Saved user SN input: ' + self.SN_folder)
                    self.SN_folder = user_input
                    return self.SN_folder
                if user_input in cancel_options:
                    log.warning('Exiting...')
                    exit(0)
                log.error('Enter SN Menu Failed... Should never get this message...')
                '''

	def menu_y_n(self, usr_input_msg, name):
                continue_options = ['yes', 'y']
                cancel_options = ['no', 'n']

                while True:
                        try:
                                response = str(raw_input(usr_input_msg + '[' +
                                                        str(continue_options).strip('[]') +
                                                         ',' +
                                                         str(cancel_options).strip('[]') +
                                                         '] : ')).lower()
                        except:
                                log.warning('Input error: invalid input')

                        if response in continue_options :
                                return True
                        elif response in cancel_options:
                                log.warning('Cancelled: ' + name)
                                return False
                        else:
                                log.warning('Input error: expected ' +
                                                 str(continue_options) + 
						 ' to continue or ' + 
						 str(cancel_options) + ' to cancel')
                                continue


	# Main Menu
	def menu(self):
                
                #self.menu_get_sn()
		
	        #Verify user menu input
        	while True :
			print (50 * '-')
			print (11 * ' ' + self.script)
			print (13 * ' ' + self.cmdsVersion)
			print (15 * ' ' + 'M A I N - M E N U')
			print (50 * '-')
			print ('1. Automated Install (Switches, SBC, etc)')
			print ('2. Upgrade single Switch or SBC')
			print ('3. Generate Logs')
			print ('4. Change Serial Port')
			print ('5. Exit')
			print (50 * '-')

	                try :
        	                choice = int ( raw_input('Enter your choice [1-5] : ') )
                	except ValueError:
                        	#Input was a string, instead of the expected int
	                        print ('Input Error: Invalid, Try again...')
        	                continue

                	if choice == 1:
                        	self.automated()
	                        break

	                elif choice == 2:
				# Ask user to select switch or sbc
                	        name = raw_input('Enter your choice [' + 
						str(self.switch_cmds).strip('[]') +
						', ' + str(self.board_cmds).strip('[]') 
						+'] : ').lower()
				# Check if switch, then run upgrade
        	                if name in self.switch_cmds:
					device = 'gbe-' + name
                	                if self.upgrade_switch(device):
						result = self.log_menu_y_n(device)
						
						return result

				# Check if board, then run upgrade
	                        elif name in self.board_cmds:
					device = 'amms_' + name

					# Verify with user, wra or edu
        	                        type = str(raw_input('wra or edu? ')).lower()
					
					# Output error if neither
                	                if type not in ('wra', 'edu'):
                        	                print ('Input Error: expected wra or edu')
                                	        continue

					# Generate log upon user request
	                                if self.upgrade_SBC(device, type):
						return self.log_menu_y_n(device)
        	                else:
                	                log.warning('Input Error: command invalid')
                        	        continue
			
			# User only wants log	
	                elif choice == 3:
				self.generate_log_menu()

			# User wants to change serial port, located in defaults.cfg
			elif choice == 4:
				self.change_serial()	
				break # Restarts program and get new serial port
	
			# Cleanly exit on user request
			elif choice == 5:
				log.warning('Exiting...')
				exit(0)

	                else:
        	                log.warning('Input Error: invalid, try again...')
	
	# Allow user to change serial port in configuration file
	def change_serial(self):
		log.warning('Current Serial Port is: ' + self.cfgParser.get('serial', 'default_port'))
		log.warning('Backup Serial Port is: ' + self.cfgParser.get('serial', 'backup_port'))
		
		if self.menu_y_n('Change Serial Port? : ', 'serial port change'):
			# Get new serial port from user
			newSerial = raw_input('Enter a new serial port: ')
			# Save old port to backup_port in config file
			if self.dirMgr.get_writeable:
				self.cfgParser.set('serial', 'backup_port', 
						self.cfgParser.get('serial', 'default_port'))
				# Set new port from user
				self.cfgParser.set('serial', 'default_port', newSerial)
				# Verify config file is open and writeable
			
				with open(self.cfgFile, 'w+') as configFile:
					# Write new serial port to config file
					self.cfgParser.write(configFile)
					# Display new serial port in config file to user
					log.warning('Changed Serial Port from: ' + 
					self.cfgParser.get('serial', 'backup_port') + ' to: ' + 
				self.cfgParser.get('serial', 'default_port'))
				return True
			else:
				log.error('Unable to write to ' + self.dirMgr.set_cfg())
		else:
			return False

	# Sub menu to generate logs
	def generate_log_menu(self):
		logCmds = ''
		while True :
			try :
				# Let user select device to lgo
				device = raw_input('Enter your choice [' +
					str(self.switch_cmds).strip('[    ]') + ', '
					+ str(self.board_cmds).strip('[]') +'] : ').lower()
	
				# Verify user selected a valid device
				if (device in self.switch_cmds) or (str(device) in self.board_cmds):
					break

				# User selected invalid device
				else:
					raise IOError()
			except:
				#Input was a string, instead of the expected int
				log.warning('Input Error: Invalid, Try again...')
				continue
		
		# Generate log for switch
		if device in self.switch_cmds:
			device = 'gbe-' + device
			logCmds = self.switchLogCmds
			#print 'switch logCmds: ' + repr(logCmds)

		# Generate log for board
		elif device in self.board_cmds:
			device = 'amms_'+ device
			logCmds = self.ammsLogCmds
			#print 'amms logCmds:' + repr(logCmds)
		# Should have been checked by user prompt, should never get
		else:
			log.error('failed to select gbe- or amms_ cmd file')
		# Run log generation
		return self.generate_log(logCmds, device)
		

	# Switch upgrade
	def upgrade_switch(self, name):
		global log
		log = logger('cfgLoader')
		# command file
        	cmdFile = name + self.cfgParser.get('file','cmds')
		# path to command file
	        dir = self.dirMgr.CMDS_path() + self.cfgParser.get('folder', 'switch_cmds')
		dir = dir.replace('\n', '')	
		#print 'switch cmd dir: ' + repr(dir)

        	log.info('Starting ' + name.upper() + ' upgrade...')
		print('Starting ' + name.upper() + ' upgrade...')
		print('Logging to ' + str(log.get_logs_file()))
		print(name.upper() + ' completes in approximately: ' + 
			self.cfgParser.get('Times', name.upper()))
		# record start time
		start = datetime.datetime.now()
		# get bool status from sending cmd file
		status = self.cmds.sendCmds(dir, cmdFile)
		# record end time
		end = datetime.datetime.now()
		if status:
			self.record_time(start, end, name.lower())
		return status

	# Generate Log
	def generate_log(self, cmdFile, device):
                print(device.upper() + ' log completes in approximately: ' +
                        self.cfgParser.get('Times', 'log_' + device.lower()))

		# initialize new logger
		cmdSender = cmds()
		# set log for specific device and create new log file
		cmdSender.setLogger(device, device)
		# record start time
		start = datetime.datetime.now()
		# save bool status from sending cmd file
		#dir = dir.replace('\n', '') # May not be required
		status = cmdSender.sendCmds(dir, cmdFile)
		# record end time
		end = datetime.datetime.now()
		if status:
			self.record_time(start, end, 'log_' + device.lower())
		return status

	# Once upgrade has completed, verify user wants a log
	def log_menu_y_n(self, device):
		if self.menu_y_n('Generate Logs for ' + device.upper() + '?: ', 'log generation' ):
			if device in self.BOARDS: 
				return self.generate_log(self.ammsLogCmds, device)
			elif device in self.switch:
				return self.generate_log(self.switchLogCmds, device)
			else: 
				log.warning('Error: invalid device')
				return False

	def record_time(self, start, end, name):
		c = end - start

                time_str = " %.2dh: %.2dm: %.2ds" % (c.seconds//3600,(c.seconds//60)%60, c.seconds%60)
                log.info('Took ' + time_str + ' to run ' + str(name.upper()))

                # save run time to defaults.cfg
                self.cfgParser.set('Times', name.lower(), time_str)
                with open(self.cfgFile, 'w+') as configFile:
                        self.cfgParser.write(configFile)
		return time_str


	# TFTP file over network
	def tftp(self, name, file):
		# get directory script is running in
        	dir = self.dirMgr.data_path()
		# build cmd instruction
        	cmd = 'tftp -m binary ' + name + ' -c put ' + file
	        log.info('TFTPing file:' + str(dir + file))
		# send cmd using current dir
        	subprocess.call(cmd, shell=True, stderr=subprocess.STDOUT, cwd=dir)

	# Upgrade SBC
	def upgrade_SBC(self, name, type):
		global log
		log = logger('cfgLoader')

		# First command file contains cmds to open tftp
	        cmdFile1 = type+'_'+name+'_01.cmds'
		# Second setsup device
        	cmdFile2 = type+'_'+name+'_02.cmds'

		# Setup cmd directory for wra/edu/cw 
	        dir = self.dirMgr.CMDS_path() + '/' + type +'/'
		dir = dir.replace('\n', '')
		#print 'SBC dir: ' + repr(dir)
		
	        #serial.connect()
        	log.info('Starting: ' + type.upper() + ' ' + name.upper() + ' SBC upgrade...')
		print('Starting: ' + type.upper() + ' '  + name.upper() + ' SBC upgrade...')
		
		start = datetime.datetime.now()
                print('Logging to ' + str(log.get_logs_file()))
                print(name.upper() + ' completes in approximately: ' +
                        self.cfgParser.get('Times', name.lower()))

		# First command file is to setup tftp link
	        if self.cmds.sendCmds(dir, cmdFile1):
                	self.tftp(name, self.tfile)
        	        time.sleep(10)

			# Once file has been sent, continue with second command file
	                status = self.cmds.sendCmds(dir, cmdFile2)
			if not status:
                        	log.error('failed to run ' + cmdFile2)
                	        return False
        	else:
			log.error('failed to run ' + cmdFile1)
                	return False
		# record end time
		end = datetime.datetime.now()
		log.info('Completed: ' + type.upper() + ' ' + name.upper() + ' SBC upgrade')
		print('Completed: ' + type.upper() + ' ' + name.upper() + ' SBC upgrade')
		if status:
			self.record_time(start, end, name.lower())
	        return True

	def automated(self):
		device = 'gbe-x'
		type = raw_input('wra or edu? ').lower()
		
		# Verify device type with user
		if type not in ('wra', 'edu'):
			log.warning('Input Error: expected wra or edu')
			return False

		log.info('Automated install started...')
		print('Automated install started...')

		if self.menu_y_n('Verify RS232 is connected to ' + device.upper(), device.upper()):
		# Verify switch upgrade completed, inform user
			if self.upgrade_switch(device):
				log.info('Successfully upgraded ' + device.upper())
				print('Successfully upgraded ' + device.upper())
				# Check if user wants to create a log
				self.log_menu_y_n(device)
			else:
				log.error('Error: Failed to upgrade ' + device.upper())
		
		device = 'gbe-y'
		# Verify cable is connected with user
		if self.menu_y_n('Verify RS232 is connected to GBE-Y ', device.upper()):
			# Verify switch upgrade completed, inform user
			if self.upgrade_switch(device):
	        		log.info('Successfully upgraded ' + device.upper())
				print('Successfully upgraded ' + device.upper())
				# Check if user wants to create a log
				self.log_menu_y_n(device)
				
	                else:
        	        	log.error('Error: Failed to upgrade ' + device.upper())

		#Go through every SBC in BOARD list
		for SBC in self.BOARDS:
			if self.menu_y_n('Verify RS232 is connected to ' + SBC.upper(),
					 SBC.upper()):
				if self.upgrade_SBC(SBC, type):
	        			log.info('Successfully upgraded ' + SBC.upper())
					print ('Successfully upgraded ' + SBC.upper())
                                	self.log_menu_y_n(SBC)
                        	else:
                                	log.error('Error: Failed to upgrade ' + SBC.upper())


#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
