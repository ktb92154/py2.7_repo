#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         cmdFileMgr.py
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems
#/ CONTRACT:        Northrop Grumman Aerospace Systems
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release                                       K. Burgess
#/==============================================================================
###############################################################################
import os
import time
import logMgr
import dirMgr
import serialMgr
import ConfigParser

class cmds(object):
	# Default constructor
	def __init__(self, name='cmdFileMgr'):
                self.fileName = ''
                
                # Directory management class
		self.dirMgr = dirMgr.mgr()
                
                # Set Logger
                self.log = logMgr.logger(name) # Create logger to generate logs
                
                # Class variables
                self.last_response = '' # Buffer to save responses
		self.CmdComment = "#" # Chosen char to ignore for comments in .cmds
                
                # Initialize Serial class
		self.serial = serialMgr.mySerial(self.dirMgr.set_cfg())

	# Start a new logger with custom name
	def setLogger(self, name, file):
		self.name = name
		self.fileName = file
		self.log = logMgr.logger(self.name, self.fileName)

	# Parse command file
	def read(self, filename):
		self.log.info('Running command file: ' + filename)
		list = []
		with open(filename) as file:
			for line in file:
				# Remove aka skip line that only contains comments
				if line.startswith(self.CmdComment):
					continue
				else:
					# cmd file comments MUST have a space separating them from command
					if (' ' + self.CmdComment) in line:
						# Remove comment and only leave command
						line = line.partition(' ' + self.CmdComment)[0]

					line = line.strip() # Remove left and right whitespaces
					# Add new line since we stripped left + right
					line += '\n'
					list.append(line)
			#print repr(list) #Uncomment to verify commands if necessary
			return list

	# Parse command file located in a specific directory
	def read_file_in_dir(self, dir, filename):
		self.full_path = os.path.join(dir, filename)
		self.full_path = self.full_path.replace('\n', '')
		return self.read(self.full_path)

	# Process "if" command
	def ifCmd(self, cmd, last, wait):
		cmdWord = "if "
                ''' Remove command word "if " '''
                cmd = cmd.replace(cmdWord, "", 1).strip()
		cmd = cmd.split()
		expect = cmd.pop(0)
		#sendCmd = cmd[1].strip()
                if expect in last:
			for i in range(len(cmd)):
	                        self.serial.send(cmd[i] + '\n')
                       		self.log.info('Found: ' + repr(expect) + ' Sent: ' + repr(cmd[i]))
				time.sleep(int(wait))
                                self.last_response = self.serial.read_response().strip()
                                self.log.info('Received: ' + self.last_response)
                        return True
                self.log.info('Did not find "' + repr(expect) + '"')
		self.log.info('Did not send "' + repr(cmd) + '"')
                return False


	# Process "expect" command
	# Used to determine if expected terminal response was received
	# Return True if found
	def expectCmd(self, cmd, last):
		cmdWord = "expect "
		#if cmdWord in cmd:	
		expect = cmd[len(cmdWord):]
		expect = expect.strip()
		got = ''
		if len(last) >= len(expect):
			for n in range(len(expect), 0, -1):
				got = got + last[-n]
			got = got.strip()
			if got == expect:
				return True
		self.log.warning('Warning did not find: ' + repr(expect) + 
                                        'received: ' + repr(got) + ' ... exiting')
		return False

	# Process "failif" command
	# Used to detect a "keyword" that indiciates a bad responses
	# Return failed if found
	def failifCmd(self, cmd, last):
		cmdWord = "failif "
                ''' Remove command word "failif " '''
                expect = str(cmd.replace(cmdWord, "", 1).strip())
		if expect in last:
			self.log.warning('Found: "' + repr(expect) +' in ' + str(last) + '" did Marc tell you to plug in the ethernet cable for SBC? ... cancelling')
			return False
		self.log.info('Success, did not find: "' + repr(expect) +' in ' + str(last) + '" continuing.')
		return True


	def saveCmd(self, cmd, msg):
		'''
		Store string found after expected string
		example: "strStore Current value  :"
		'''
		cmdWord = "strStore " 
		#if cmdWord in cmd:
		# remove cmdWord from cmd
		''' Remove command word "strStore" '''
		cmd = cmd.replace(cmdWord, "", 1).strip()
		# veryify expected string is in msg
		'''Verify remaining expected string "Current value  :" is found.'''
		if cmd in msg:
			# remove expected string and everything before variable
			'''
			Remove expected string "Current value :" from msg
			'''
			saveVar = msg.split(cmd,1)[-1]
			# remove everything after variable's newline
			'''
			Remove everything after new line
			'''
			saveVar = saveVar.split('\r\n')[0].strip()
			self.log.info('Saved: ' + repr(saveVar))
			'''
			Finally, return the found string
			'''
			return saveVar
		return ''

	def useVarCmd(self, cmd, savedVar, wait):
		cmdWord = "useVar"
		print "***************************************"
		if cmdWord in cmd:
			cmd = cmd.replace(cmdWord, savedVar, 1).strip('\n')
			print "useVar replaced with: " + cmd
			print cmd
			self.log.info('Saved var sent in: ' + str(cmd))
			self.serial.send(cmd)
                        time.sleep(int(wait))
			print "************************************"
			return True
		self.log.error('Failed to send saved var: ' + repr(savedVar) )
		return False
        
        def useFileVarCmd(self, sub_dir,  cmd):
                cmdWord = "useFileVar"
                
                # Set Configuration Parsers
                varFile = self.dirMgr.CMDS_path()
		#print 'varFile: ' + repr(varFile)

                try:
                    fileParser = ConfigParser.ConfigParser()
                    fileParser.read(self.dirMgr.set_cfg())
                    file = fileParser.get('file', 'cmdVarFile') # Get command variables file name from defaults.cfg
                    #print 'File: ' + repr(file)
                    #print repr(dict(fileParser.items('file')))
                    defaultSection = fileParser.get('file', 'cmdVarFileDefault') # Get command variables file name from defaults.cfg
                    #print 'defaultSection in file: ' + repr(defaultSection)
                except:
                    self.log.error('Failed to read file in: ' + sub_dir)
                    return False
                
                section = ''
                option = ''
                verifyList = ''
                if cmdWord in cmd:
                        dataFileParser = ConfigParser.ConfigParser()
                        cmdParts = cmd.split(' ') # Split command into list by spaces
                        
                        # Read variable data file in current command folder (wra, edu, etc)
                        try:
                            dataFileParser.read(sub_dir + file) # Read command variables file
                        except:
                            self.log.error('Failed to read file: ' + sub_dir + file)
                            return False 

                        i = cmdParts.index(cmdWord) + 1 # Find position of command in list, next list item is file SECTION
                        section = cmdParts.pop(i).strip() # save section name and remove
                        #print 'SECTION: ' + repr(section)
                        try:
                            verifyList = repr(dict(dataFileParser.items(section)))
                            #print repr(verifyList)
                        except: # catch *all* exceptions
                            self.log.info('In ' + cmdWord + ' SECTION OPTION command SECTION not found.')
                            
                        # Check if list is empty
                        # Empty list signifies SECTION not found in file
                        if not bool(verifyList):
                            self.log.info('Section not found. Using default ' + defaultSection)
                            option = section
                            
                            # Since no SECTION was specified, try default SECTION
                            try:
                                verifyList = repr(dict(dataFileParser.items(defaultSection)))
                                # verified default SECTION was found, set for later use
                                section = defaultSection
                            except: 
                                # No point in attempting to read file again if default section failed.
                                self.log.error('Error: default section ' + defaultSection + 'not found. Unable to use ' + cmdWord)
                                return False
                        else:
                            # Valid SECTION, get OPTION
                            option = cmdParts.pop(i).strip()
                        
                        print 'option from cmd: ' + repr(option)

                        # Either user SECTION or default SECTION was found, read OPTION for variable 
                        try:
                            #print 'SECTION: ' + section + ' OPTION: ' + option
                            fileVar = dataFileParser.get(section, option)
			    #print 'fileVar: ' + fileVar
                        except: # catch *all* exceptions

                            self.log.error('Failed to use ' + cmdWord + ' SECTION OPTION or ' + cmdWord + ' OPTION from ' + sub_dir + file)
                            return False
			
			cmdParts[cmdParts.index(cmdWord)] = fileVar # replace command word with string in file 
                        newCmd = " ".join(cmdParts) + '\n' # combine list into new command, spaced
                        #print 'newCmd: ' +  repr(newCmd)
			self.log.info('Success: Variable read from file. Created new command: ' + repr(newCmd))
			return newCmd
		self.log.error('Error: failed to find command ' + cmdWord)
		return False

	def strInsertCmd(self, cmd, savedVar):
		cmdWord = "strInsert "
		cmdWord2 = "useVar"
		#if cmdWord in cmd:
		# remove first command from string
		cmd = cmd.replace(cmdWord, '', 1).strip('\n')
		# check if altering saved variable
		if cmdWord2 in cmd:
			if savedVar != '':
				# replace second command with saved variable
				cmd = cmd.replace(cmdWord2, savedVar, 1) 
		list = cmd.split()
		# first word in string is the one to be altered
		string = list[0]
		# second word in string is the position to insert
		# third word is the item to insert into string
		string = string[:int(list[1])]+ list[2] + string[int(list[1]):]
		return str(string)
			
		
	def pauseCmd(self, cmd):
		cmdWord = "setPause"	
		num = 1
		if cmdWord in cmd:
			num = cmd[len(cmdWord):]
			
		self.log.info('sleep set: ' + num)
		return num

	def sendCmds(self, sub_dir, cmd_file):
                #print 'sub_dir after: ' + repr(sub_dir)
		cmds = self.read_file_in_dir(sub_dir, cmd_file)

		wait = 1 #Sleep for
		save = ''
		
		for i in range(len(cmds)):
			#Command to wait for expected response
			if "setPause" in cmds[i]:
				wait = self.pauseCmd(cmds[i])
			elif "strStore" in cmds[i]:
				save = self.saveCmd(cmds[i], self.last_response)
			elif "expect" in cmds[i]:
				if self.expectCmd(cmds[i], self.last_response) == False:
					return False
			elif "failif" in cmds[i]:
				if self.failifCmd(cmds[i], self.last_response) == False:
					return False
			elif "if " in cmds[i]:
				self.last_response = self.ifCmd(cmds[i], self.last_response, wait)
			elif "strInsert" in cmds[i]:
				save = self.strInsertCmd(cmds[i], save)
			elif "useVar" in cmds[i]:
				self.useVarCmd(cmds[i], save, wait)
                        elif "useFileVar" in cmds[i]:
		                newCmd = self.useFileVarCmd(sub_dir, cmds[i])
				self.serial.send(newCmd)
				self.log.info('Sent: ' + newCmd)
				self.last_response = self.serial.read_response().strip()
				self.log.info('Received: ' + self.last_response)
			else:
				self.log.info('Sent: ' + cmds[i])
				self.serial.send(cmds[i])
				time.sleep(int(wait))	
				self.last_response = self.serial.read_response().strip()
				self.log.info('Received: ' + self.last_response)
		return True

#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
