#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         constants.py
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems
#/ CONTRACT:        Northrop Grumman Aerospace Systems
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release  v1.0.0.0                             K. Burgess
#/ 05/11/15    Initial Release  v1.0.0.1                             R. Green
#/==============================================================================
###############################################################################

# Store the version here so:
# 1) we don't load dependencies by storing it in __init__.py
# 2) we can import it in setup.py for the same reason
# 3) we can import it into your module module


__program__ = 'AMMS CFG Loader'
__version__ = '1.0.0.2'

''' 
Version 1.0
        1. Initial Release
        2. Automated step by step install for all devices
        3. Single switch or SBC install
        4. Ability to create logs for switch or SBC in ~/amms_loader_logs/date/
        5. Logger to save input/output to AMMS-CFG_loader.log
        6. read .cmd files and send to serial port
        7. defaults.cfg control global variables
        8. logging.cfg changes how logger outputs to terminal or log file
        9. Added exit option to menu
        10. Added version to menu, controlled by defaults.cfg
        11. Changed time/date format of .logs
        12. Cleaned up code
        13. Added check for imports, output error, and exit cleanly if a python module is not installed
        14. Added ability to put spaces/tabs in .cmd files for easier reading
        15. filter ^M (\r\r\n) from being written to logs
        16. Added menu option to change default serial port in defaults.cfg

Future capability aka TODO list:
        1. Add parallel processing if serial hub is available
           in order to allow all 10 devices to be done at once
        4. create portable version that doesn't require python libraries to be installed
'''


#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------

