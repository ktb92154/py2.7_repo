#!/usr/bin/python

#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         dirMgr.py
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems
#/ CONTRACT:        Northrop Grumman Aerospace Systems
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release  v1.0                                 K. Burgess
#/ 03/26/15    Added Capability v1.0                                 K. Burgess
#/==============================================================================
##############################################################################
import subprocess
#import sys
import shutil
import os
import ConfigParser
from .terminal import *

class mgr(object):
	# Class global variables
	writeable = False # for CD, HDD, detection
	def __init__(self):
		# Set Configuration Parsers
		self.cfg = ConfigParser.ConfigParser()
		self.cmdsConfigParser = ConfigParser.ConfigParser()
                
		# Check configuration file directory
		if os.path.isdir('py_script'):
			self.cfg.read(os.getcwd() + '/py_script' + '/defaults.cfg')
		else:
			self.cfg.read(os.getcwd() + '/defaults.cfg')
                        
		# Copy full path to current user directory
		self.home = os.path.expanduser('~/')
                
		# Write full path to script directory
		self.scriptDir = ( self.home + self.cfg.get('folder', 'loader'))
		
		# Detect if config file is in user directory, else default cfg over
		self.cfgFile = self.set_cfg()
                
		# Read config file with config parser
		#print self.cfg.read(self.cfgFile)
		self.cfg.read(self.cfgFile)
                
		# Load folder name from config, where commands will be found
		self.cmd_dir = self.cfg.get('folder','cmds')
		self.versionFile = os.path.abspath(__file__ + "/../../") + '/' + self.cmd_dir + '/' + self.cfg.get('file', 'cmdsVersion')
		#print self.versionFile
                self.cmdsConfigParser.read(self.versionFile)
		
		self.cmdsVersion = self.cmdsConfigParser.get('GENERAL', 'version')
		self.cmdsType = self.cmdsConfigParser.get('GENERAL', 'type')
		
	# Create log directory in user home
	def set_logs_dir(self, date):
		try:
			logsDir = (self.scriptDir + self.cfg.get('folder', 'logs'))
			logsDir = (str(logsDir) + str(date) + '/')
			if not os.path.exists(logsDir):
				os.makedirs(logsDir)
				#print('\033[92m'+ 'Created directory: ' + str(logsDir) + '\033[0m')
				print(bcolors.OKGREEN+ 'Created directory: ' + str(logsDir) + bcolors.ENDC)
			return logsDir
		except:			
			print(bcolors.FAIL+ 'Failed to create local log directory' + bcolors.ENDC)

	# Create configuration file in user home
	# Else use default config from script directory
	def set_cfg(self):
		global writable
		cfgDir = (self.scriptDir + self.cfg.get('folder', 'cfg'))
		localFile = 'py_script/defaults.cfg'
		file = str(cfgDir) + 'defaults.cfg'
		
		# If dir doesn't exist, create dir in user home
		if not os.path.exists(cfgDir):
			os.makedirs(cfgDir)
			print(bcolors.OKGREEN + 'Created directory: ' + str(cfgDir) + bcolors.ENDC)

		# If config file doesn't exit, copy from script folder
		if not os.path.isfile(file):
			try: 
				shutil.copy(localFile, file)
				print(bcolors.OKGREEN + 'Copied ' + localFile  + ' to ' + file + bcolors.ENDC)
				writable = True
				return file
			except:
				print(bcolors.FAIL + 'Error: unable to move defaults.cfg to self.home dir' + bcolors.ENDC)
				print(bcolors.FAIL + 'Warning: reverted to /py_script/defaults.cfg' + bcolors.ENDC)
				writeable = False
				return localFile			
		return file
                

	def get_cmds_version(self):
		return self.cmdsVersion

	def get_cmds_type(self):
		return self.cmdsType

	def get_cfg(self):
		print ('*** ' + self.cfgFile + ' ***')
		return self.cfgFile

	def get_writeable(self):
		global writable
		return writable

	def data_path(self):
		dir = os.getcwd()
		if  os.path.exists(dir + "/data/"):
			dir = dir + "/data/"
			#print repr(dir)
			return dir

		else:
			print(bcolors.FAIL + 'Error: data path does not exist' + bcolors.ENDC)
			exit()

	# Check script folder location
	def CMDS_path(self):
		cmd = subprocess.Popen('pwd', stdout=subprocess.PIPE)
		cmd_out, cmd_err = cmd.communicate()

	       #Determine if main.py is running from py_scripts folder
		if  os.path.exists('../' + self.cmd_dir + '/'):
			dir = cmd_out.replace('/py_script', '/' + self.cmd_dir).strip()
			#print 'logsDir: ' + repr(dir)
			return dir

		#Determine if main.py is running as a soft_link from AMMS_CFG folder
		elif os.path.exists(self.cmd_dir):
			dir = (cmd_out + '/' + self.cmd_dir).strip()
			return dir
		else:
			#Folder does not exist or main.py is running from a non predetermined folder
			print('Path Error: ' + self.cmd_dir + ' path does not exist')
			exit()

#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
