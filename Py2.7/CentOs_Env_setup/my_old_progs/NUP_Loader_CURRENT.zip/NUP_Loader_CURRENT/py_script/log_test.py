#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         log_test.py
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/                      
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems                   
#/ CONTRACT:        Northrop Grumman Aerospace Systems            
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release                                       K. Burgess
#/==============================================================================
############################################################################### 
import logMgr

log1 = logMgr.logger('amms_04')
#log1.myLogger('amms_04')
log2 = logMgr.logger('amms_05')
#log2.myLogger('amms_05')

log1.info('test1')
log1.info('test2')
log1.debug('test3')
log1.warning( 'test4')
log1.error( 'test5')

log2.info('test1')
log1.info('test2')
log2.info('test2')
log2.debug('test3')
log2.warning( 'test5')

<<<<<<< .mine
#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
=======

#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
>>>>>>> .r709
