#/==============================================================================
#/
#/ Unclassified                  U N C L A S S I F I E D           Unclassified
#/
#/ FILE:                         serialMgr.py
#/
#/ DESCRIPTION:         Python script to configure AMMS switches and boards
#/                      
#/
#/ AUTHOR:          K. Burgess
#/
#/ COMPANY:         Northrop Grumman Corporation
#/ SECTOR:          Aerospace Systems
#/ BUSINESS AREA:   HALE Enterprise Mission Systems
#/ ADDRESS:         17066 Goldentop Road
#/                  340-2C Building 2
#/                  San Diego, CA 92127-2412
#/
#/ PROJECT:         Unmanned Systems                   
#/ CONTRACT:        Northrop Grumman Aerospace Systems            
#/ CSCI:            AMMS
#/ CSC:             SCRIPTS
#/
#/ CHANGE HISTORY:
#/
#/ Date         Description of Change                                Programmer
#/ ---------    -------------------------------------------------    -----------
#/ 02/25/15    Initial Release                                       K. Burgess
#/==============================================================================
############################################################################### 
import serial, time, sys, glob, platform, fcntl
import ConfigParser
from .logMgr import logger


log = logger('root')

class mySerial(object):
	def __init__(self, cfgFile):
		self.cfgFile = cfgFile
		self.device = ''
		self.com1 = None
		self.cfg = ConfigParser.ConfigParser()
		self.cfg.read(self.cfgFile)
		try:
			self.device = self.cfg.get('serial','default_port')
			self.com1 = serial.Serial(self.device)
			self.connect()
		except:
			log.warning('Unable to read default serial port, reverting to backup port!')
			log.warning('Change in menu or manually in ' + self.cfgFile)
			try: 
				
				self.device = self.cfg.get('serial','backup_port')
				self.com1 = serial.Serial(self.device)
				self.connect()
			except Exception, err:
				log.error('Default and backup serial port failed')
				log.error(err)
				log.warning('Change manually in ' + self.cfgFile)


	def list_serial_ports(self):
		system_name = platform.system()
		if system_name == 'Windows':
			log.error('Not designed for Windows... exiting...')
			sys.exit()
		elif system_name == 'Darwin':
			# Mac
			log.error('Not designed for Mac... exiting...')
			sys.exit()
		elif system_name == 'Linux':
			log.info('Default serial port is: ' + self.device)
			log.info('Change serial port in ' + self.configFile + ' if necessary.')
		else:
			raise EnvironmentError('Unsupported platform')

		
	def connect(self):
		if self.com1.isOpen():
			self.close()
		try:
			#log.info( 'Changing com1 settings')
			self.com1.baudrate=int(self.cfg.get('serial','baudrate'))
			self.com1.bytesize=int(self.cfg.get('serial','bytesize'))
			self.com1.stopbits=int(self.cfg.get('serial','stopbits'))
			self.com1.timeout=int(self.cfg.get('serial','timeout'))
			self.com1.xonxoff=False
			self.com1.rtscts=False
			self.com1.parity=serial.PARITY_NONE
			self.com1.open()

			#log.info('Serial Status: opened connection')
		except IOError as e:
			if self.com1.isOpen(): 
				self.close()
			log.error('Serial: I/O connection failed!' + repr(e))
			sys.exit()
		except Exception as e:
			if self.com1.isOpen(): 
				self.close()
			log.error('Serial: general exception when trying to connect')
			sys.exit()

	def close(self):
		self.com1.close()
		#logSerial.warning('Serial Status: closed connection')

	# Reads one response from serial port
	def read_response(self):
		try:
			while self.com1.isOpen():
				while True:
					# Did not get a response in a reasonable amount of time
					tdata = self.com1.read() # wait forever for anything
					if len(tdata) == 0:
						return tdata
					time.sleep(1) # Sleep (or inWaiting() doesn't give correct value)
					data_left = self.com1.inWaiting() # Get the number of cars ready to be read
					tdata += self.com1.read(data_left) # Do the read and combine it with the first character
					if tdata :
                                                #print tdata
						return tdata
		except Exception:
			log.error('Error: unable to read serial port')
			return -1


	def send(self, cmd):
		#log.info('Using serial port: ' + self.device) 
		if self.com1 == None :
			log.error('Rerun and change serial port in defaults.cfg... exiting program')
			sys.exit(1)
		if not self.com1.isOpen():
			self.connect()	
		try:
			if self.com1.isOpen():
				''' before writing anything, ensure empty buffer '''
				if self.com1.inWaiting() > 0:
					self.com1.flushInput() # clear input
					self.com1.flushOutput() # clear output

                                # Send only space
                                if '\s' in cmd:
                                        #print "cmd is: " + repr(cmd)
					self.com1.write(' ')
                                # send newline if command is empty
				elif cmd == '':
                                        #print "writting \n"
					self.com1.write('\n')
                                else:
                                    #print "writting: " + repr(cmd)
				    self.com1.write(cmd)
		except Exception:
                        log.error("Serial Send Failed")
			self.close()
		
		return 'Serial Error: send failed!'
#---------------------------------------------------------------------------
#*******************************UNCLASSIFIED********************************
#***************************************************************************
#***                                                                     ***
#***  U   U NN   N  CCCC L      AAA   SSSS  SSSS I FFFFF I EEEEE DDDD    ***
#***  U   U N N  N C     L     A   A S     S     I F     I E     D   D   ***
#***  U   U N  N N C     L     AAAAA  SSS   SSS  I FFFF  I EEEE  D   D   ***
#***  U   U N   NN C     L     A   A     S     S I F     I E     D   D   ***
#***   UUU  N    N  CCCC LLLLL A   A SSSS  SSSS  I F     I EEEEE DDDD    ***
#***                                                                     ***
#***************************************************************************
#*******************************UNCLASSIFIED********************************
#---------------------------------------------------------------------------
