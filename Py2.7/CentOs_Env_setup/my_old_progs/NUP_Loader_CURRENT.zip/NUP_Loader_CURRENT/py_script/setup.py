from cx_Freeze import setup, Executable
import sys
import ConfigParser

cfg = ConfigParser.ConfigParser()
cfg.read('defaults.cfg')

author = cfg.get('GENERAL','author')
name = cfg.get('GENERAL','name')
version = cfg.get('GENERAL','version')


# Dependencies are automatically detected, but it might need
# fine tuning.
buildOptions = dict(packages = [], excludes = [])

base = 'Console'

executables = [
    Executable(script = '../main.py', 
		base=base, 
		targetName = 'run', 
		targetDir = name + version)
]

setup(name = name,
      version = version,
      author = author,
      description = 'Loads AMMS Configuration File to AMMS',
      options = dict(build_exe = buildOptions),
      executables = executables)
