addHeaderFooter module
======================

.. automodule:: addHeaderFooter
    :members:
    :undoc-members:
    :show-inheritance:
