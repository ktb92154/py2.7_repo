PYTHON_VER="Python 2.7.9" #Verify PYTHON_VER number matches PYTHON_OK number
PYTHON_FILE="Python-2.7.9"
PYTHON_CMD='python --version'
PYTHON=$(($PYTHON_CMD) 2>&1)
DIR=$(pwd)
PATH_VAR=$(PATH)
clear   # clear terminal window
echo "Starting install script."

echo "Checking if root"
if [ "$(id -u)" != "0" ]; then
        echo "You don't have sufficient privileges to run this script."
        exit 1
fi

if [ "$PYTHON" != "$PYTHON_VER" ]; then
        echo "Must install $PYTHON_VER"

        if [ -f "$PYTHON_FILE.tgz" ]; then
                echo "Installing $PYTHON_FILE"
                tar xvzf "$PYTHON_FILE.tgz" > /dev/null;
                cd $PYTHON_FILE
                ./configure > /dev/null;
                make > /dev/null;
                sudo make install > /dev/null;
		rm -rf $PYTHON_FILE
		echo "Add :/usr/local/bin to /etc/profile"
        fi
fi

mv *.tgz installed
cd $DIR

if [ "$PYTHON" != "$PYTHON_VER" ]; then
        echo "$PYTHON_VER is not installed"
        exit 1
fi

### untar every tar folder in pythonlib ###
for i in *.tar.gz;
        do echo "*** untaring: " $i " ***";
        tar xvzf $i > /dev/null; #surpress normal output but show errors
done

### go into every folder and run setup.py install ###

for i in */; do
	if [ "$i" != "installed/" ]; then
		echo "*** preparing to install " $i " ***";
        	cd $i;
	        python setup.py install > /dev/null; #surpress normal output but show errors
        	cd ..;
		rm -r $i
	        echo "*** done installing: " $i " ***"
	fi
done

mv *.tar.gz installed

echo "*** Script done ***"



