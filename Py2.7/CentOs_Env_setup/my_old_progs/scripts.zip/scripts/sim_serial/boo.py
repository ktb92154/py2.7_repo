import os, serial
import pty
from multiprocessing import Process

masters = []

def f(name):
    print('hello', name)

def tty_sim():
    try:
        master, slave = pty.openpty()
        print "master: " + str(master)
        masters.append(master)
        #print "slave: " + str(slave)

        s_name = os.ttyname(slave)
        print "s_name: " + str(s_name)
    
        ser = serial.Serial(s_name)
    
        #print "ser: " + str(ser)
    
        # To Write to the device
        ser.write('Your text')
        #ser.flush()
        #ser.read(10)
        #print ser.read()
        # To read from the device
        #print os.read(master,1000)
    except Exception, e:
        print e

if __name__ == '__main__':
    p = []
    for x in range(0, 10):
        p.append(Process(target=tty_sim(), args=()))
        p[x].start()
    
    test = serial.Serial('/dev/pts/12')
    print test.isOpen()
    test.write('test1')
    
    for x in range(0, 10):
        print os.read(masters[x],1000)
    
    
    
    for x in range(0, 10):
        p[x].join()

