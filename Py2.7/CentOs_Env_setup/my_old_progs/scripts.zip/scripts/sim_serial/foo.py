## foo.py ##
import myserial as serial
#import serial ## Use this in production

port = serial.Serial()
port.open()
print port.write("hello world")
print port.read(3)
####
