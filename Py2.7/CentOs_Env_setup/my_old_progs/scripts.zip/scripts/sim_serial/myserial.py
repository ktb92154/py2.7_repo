##myserial.py ##
class Serial:
     def __init__(self, port=None):
         pass
     def open(self):
         pass
     def close():
         pass
     def read(size=1):
         return 'a' * size
     def write(data):
         return len(data)
#####
