import pty
ptys = pty.openpty()  # create two connected ptys for testing
master = pytty.TTY(ptys[0])
slave = pytty.TTY(ptys[1])
slave.write('Greetings, Master.'.encode()) == 18
slave.flush()
print(master.read().decode())